/*
 * Layer Drop v2 - host script (ExtendScript, runs inside Premiere Pro)
 *
 * Premiere's scripting API cannot create adjustment layers or color mattes from
 * scratch, so Layer Drop keeps one "source" of each in a bin called "Layer Drop"
 * and reuses them. The first time in a project you make one of each by hand
 * (File > New > Adjustment Layer / Color Matte) and Layer Drop adopts it.
 */

var LD_BIN_NAME = "Layer Drop";
var TICKS_PER_SECOND = 254016000000;

function ldResult(ok, msg) {
    return (ok ? "OK|" : "ERR|") + msg;
}

/* ---------- Finding the source items ---------- */

function ldFindBin(parent, name) {
    for (var i = 0; i < parent.children.numItems; i++) {
        var c = parent.children[i];
        if (c.type === ProjectItemType.BIN && c.name === name) {
            return c;
        }
    }
    return null;
}

function ldGetBin() {
    var root = app.project.rootItem;
    return ldFindBin(root, LD_BIN_NAME) || root.createBin(LD_BIN_NAME);
}

function ldNoMedia(item) {
    try {
        var p = item.getMediaPath();
        return !p || p === "";
    } catch (e) {
        return false;
    }
}

function ldIsAdjustment(item) {
    if (!item || item.type !== ProjectItemType.CLIP) { return false; }
    try {
        if (typeof item.isAdjustmentLayer === "function") {
            return item.isAdjustmentLayer();
        }
    } catch (e) {}
    return ldNoMedia(item) && item.name.toLowerCase().indexOf("adjustment") !== -1;
}

function ldIsMatte(item) {
    if (!item || item.type !== ProjectItemType.CLIP) { return false; }
    if (ldIsAdjustment(item)) { return false; }
    return ldNoMedia(item) && item.name.toLowerCase().indexOf("matte") !== -1;
}

function ldSearch(parent, test) {
    for (var i = 0; i < parent.children.numItems; i++) {
        var c = parent.children[i];
        if (c.type === ProjectItemType.BIN) {
            var f = ldSearch(c, test);
            if (f) { return f; }
        } else if (test(c)) {
            return c;
        }
    }
    return null;
}

function ldGetSource(kind) {
    var test = kind === "matte" ? ldIsMatte : ldIsAdjustment;
    var bin = ldGetBin();
    for (var i = 0; i < bin.children.numItems; i++) {
        if (test(bin.children[i])) { return bin.children[i]; }
    }
    var any = ldSearch(app.project.rootItem, test);
    if (any) {
        try { any.moveBin(bin); } catch (e) {}
        try { any.name = kind === "matte" ? "LD Color Matte" : "LD Adjustment Layer"; } catch (e2) {}
    }
    return any;
}

function ldStatus() {
    if (!app.project) { return ldResult(false, "No project open."); }
    var a = ldGetSource("adjustment") ? 1 : 0;
    var m = ldGetSource("matte") ? 1 : 0;
    return ldResult(true, "STATUS:" + a + ":" + m);
}

/* ---------- Timeline helpers ---------- */

function ldTime(seconds) {
    var t = new Time();
    t.seconds = seconds;
    return t;
}

function ldFrameSeconds(seq) {
    // seq.timebase is ticks per frame, as a string.
    var tpf = parseFloat(seq.timebase);
    if (!tpf || isNaN(tpf)) { return 1 / 25; }
    return tpf / TICKS_PER_SECOND;
}

function ldTrackIsFree(track, startSec, endSec) {
    for (var i = 0; i < track.clips.numItems; i++) {
        var c = track.clips[i];
        if (c.start.seconds < endSec - 0.0001 && c.end.seconds > startSec + 0.0001) {
            return false;
        }
    }
    return true;
}

function ldTrackIndexOf(seq, trackItem) {
    for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var tr = seq.videoTracks[t];
        for (var k = 0; k < tr.clips.numItems; k++) {
            if (tr.clips[k].nodeId === trackItem.nodeId) { return t; }
        }
    }
    return 0;
}

function ldAddTopTrack(seq) {
    app.enableQE();
    var qeSeq = qe.project.getActiveSequence();
    qeSeq.addTracks(1, seq.videoTracks.numTracks, 0);
}

// First free track above `aboveIndex` for the span; adds a track if needed.
function ldFreeTrack(seq, aboveIndex, startSec, endSec) {
    for (var v = aboveIndex + 1; v < seq.videoTracks.numTracks; v++) {
        if (ldTrackIsFree(seq.videoTracks[v], startSec, endSec)) { return v; }
    }
    var before = seq.videoTracks.numTracks;
    try { ldAddTopTrack(seq); } catch (e) {}
    if (seq.videoTracks.numTracks > before) { return seq.videoTracks.numTracks - 1; }
    return -1;
}

function ldApplyEffect(trackIndex, startSec, effectName) {
    if (!effectName || effectName === "" || effectName === "None") { return ""; }
    try {
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence();
        var qeTrack = qeSeq.getVideoTrackAt(trackIndex);
        var fx = qe.project.getVideoEffectByName(effectName);
        if (!fx) { return " (effect \"" + effectName + "\" not found)"; }
        for (var i = 0; i < qeTrack.numItems; i++) {
            var it = qeTrack.getItemAt(i);
            if (!it || it.type === "Empty") { continue; }
            var s = NaN;
            try { s = it.start.secs; } catch (e1) {}
            if (isNaN(s)) {
                try { s = parseFloat(it.start.ticks) / TICKS_PER_SECOND; } catch (e2) {}
            }
            if (Math.abs(s - startSec) < 0.01) {
                it.addVideoEffect(fx);
                return "";
            }
        }
        return " (couldn't attach effect)";
    } catch (e) {
        return " (effect failed: " + e.toString() + ")";
    }
}

function ldPlace(seq, src, trackIndex, startSec, endSec, effectName) {
    var track = seq.videoTracks[trackIndex];
    track.overwriteClip(src, ldTime(startSec));
    for (var c = 0; c < track.clips.numItems; c++) {
        var clip = track.clips[c];
        if (Math.abs(clip.start.seconds - startSec) < 0.001) {
            clip.end = ldTime(endSec);
            break;
        }
    }
    return ldApplyEffect(trackIndex, startSec, effectName);
}

/* ---------- Main entry ----------
 * kind:   "adjustment" or "matte"
 * mode:   "perClip"  - one layer over each selected clip, full length (click)
 *         "cuts"     - a short layer at the start (cut) of each selected clip (Shift)
 *         "span"     - one layer covering every selected clip (Ctrl/Cmd)
 *         "playhead" - ignore the selection, add at the playhead (Alt/Opt)
 * defaultFrames: length of playhead and cut layers, in frames
 * effectName:    built-in effect to add to each new layer, or "None"
 */
function ldAdd(kind, mode, defaultFrames, effectName) {
    var spanAll = mode === "span";
    var forcePlayhead = mode === "playhead";
    var atCuts = mode === "cuts";
    try {
        if (!app.project) { return ldResult(false, "No project open."); }
        var seq = app.project.activeSequence;
        if (!seq) { return ldResult(false, "Open a sequence first."); }
        var src = ldGetSource(kind);
        if (!src) { return ldResult(false, "SETUP_" + kind.toUpperCase()); }
        if (kind === "matte") { effectName = "None"; }

        // Collect selected video clips.
        var clips = [];
        if (!forcePlayhead) {
            var sel = seq.getSelection();
            for (var i = 0; i < sel.length; i++) {
                if (sel[i].mediaType === "Video") {
                    clips.push({
                        start: sel[i].start.seconds,
                        end: sel[i].end.seconds,
                        track: ldTrackIndexOf(seq, sel[i])
                    });
                }
            }
        }

        var notes = "";
        var placed = 0;

        if (clips.length === 0) {
            // Nothing selected: add at the playhead.
            var st = seq.getPlayerPosition().seconds;
            var en = st + Math.max(1, defaultFrames) * ldFrameSeconds(seq);
            var top = -1;
            for (var t = 0; t < seq.videoTracks.numTracks; t++) {
                if (!ldTrackIsFree(seq.videoTracks[t], st, st + 0.001)) { top = t; }
            }
            var target = ldFreeTrack(seq, top, st, en);
            if (target === -1) { return ldResult(false, "No free track. Add one and try again."); }
            notes += ldPlace(seq, src, target, st, en, effectName);
            return ldResult(true, "Added at playhead on V" + (target + 1) + "." + notes);
        }

        if (spanAll) {
            var s = 1e12, e = -1, topTrack = 0;
            for (var j = 0; j < clips.length; j++) {
                if (clips[j].start < s) { s = clips[j].start; }
                if (clips[j].end > e) { e = clips[j].end; }
                if (clips[j].track > topTrack) { topTrack = clips[j].track; }
            }
            var tgt = ldFreeTrack(seq, topTrack, s, e);
            if (tgt === -1) { return ldResult(false, "No free track. Add one and try again."); }
            notes += ldPlace(seq, src, tgt, s, e, effectName);
            return ldResult(true, "Added one layer across " + clips.length + " clips." + notes);
        }

        // One layer per clip. Lower tracks first so stacks build upward neatly.
        // "cuts" mode (Shift):
        //  - one clip selected: a short layer at its start
        //  - several clips: a short layer centered on each cut between them,
        //    half before and half after, like a transition
        if (atCuts && clips.length > 1) {
            var fs = ldFrameSeconds(seq);
            var total = Math.max(1, defaultFrames);
            var before = Math.floor(total / 2) * fs;
            var after = (total - Math.floor(total / 2)) * fs;

            clips.sort(function (a, b) { return a.start - b.start; });
            var first = clips[0].start;
            var cuts = [];
            for (var q = 0; q < clips.length; q++) {
                var t0 = clips[q].start;
                if (t0 - first < 0.0005) { continue; } // skip the very first clip's start
                var dup = false;
                for (var r = 0; r < cuts.length; r++) {
                    if (Math.abs(cuts[r] - t0) < 0.0005) { dup = true; break; }
                }
                if (!dup) { cuts.push(t0); }
            }
            if (cuts.length === 0) {
                return ldResult(false, "The selected clips all start at the same time, so there's no cut between them.");
            }

            for (var u = 0; u < cuts.length; u++) {
                var cut = cuts[u];
                // Sit above every selected clip touching this cut.
                var topAtCut = 0;
                for (var w = 0; w < clips.length; w++) {
                    var cl = clips[w];
                    var touches = Math.abs(cl.start - cut) < 0.0005 || Math.abs(cl.end - cut) < 0.0005 ||
                                  (cl.start < cut && cl.end > cut);
                    if (touches && cl.track > topAtCut) { topAtCut = cl.track; }
                }
                var ls = Math.max(0, cut - before);
                var le = cut + after;
                var trk = ldFreeTrack(seq, topAtCut, ls, le);
                if (trk === -1) { continue; }
                notes = ldPlace(seq, src, trk, ls, le, effectName) || notes;
                placed++;
            }
            if (placed === 0) { return ldResult(false, "No free track. Add one and try again."); }
            return ldResult(true, "Added " + placed + " layer" + (placed > 1 ? "s" : "") + " on the cuts." + notes);
        }

        // One layer per clip (click), or a short layer at the start of a single clip (Shift).
        var cutLen = Math.max(1, defaultFrames) * ldFrameSeconds(seq);
        clips.sort(function (a, b) { return a.track - b.track || a.start - b.start; });
        for (var k = 0; k < clips.length; k++) {
            var c = clips[k];
            var cEnd = atCuts ? Math.min(c.end, c.start + cutLen) : c.end;
            var tr = ldFreeTrack(seq, c.track, c.start, cEnd);
            if (tr === -1) { continue; }
            notes = ldPlace(seq, src, tr, c.start, cEnd, effectName) || notes;
            placed++;
        }
        if (placed === 0) { return ldResult(false, "No free track. Add one and try again."); }
        return ldResult(true, "Added " + placed + " layer" + (placed > 1 ? "s" : "") + "." + notes);
    } catch (err) {
        return ldResult(false, "Error: " + err.toString());
    }
}
